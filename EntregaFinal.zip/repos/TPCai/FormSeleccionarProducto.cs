﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Entidades;
using Negocio;

namespace TPCai
{
    public partial class FormSeleccionarProducto : Form
    {
        private readonly VentaNegocio _ventaNegocio = new VentaNegocio();
        public List<ItemVenta> ProductosSeleccionados { get; private set; } = new List<ItemVenta>();

        public FormSeleccionarProducto()
        {
            InitializeComponent();
        }

        private void FormSeleccionarProducto_Load(object sender, EventArgs e)
        {
            cmbCategoria.Items.Clear();
            cmbCategoria.Items.Add(new Categoria { Id = 1, Nombre = "Audio" });
            cmbCategoria.Items.Add(new Categoria { Id = 2, Nombre = "Celulares" });
            cmbCategoria.Items.Add(new Categoria { Id = 3, Nombre = "Electro Hogar" });
            cmbCategoria.Items.Add(new Categoria { Id = 3, Nombre = "Informática" });
            cmbCategoria.Items.Add(new Categoria { Id = 3, Nombre = "Smart TV" });

            cmbCategoria.DisplayMember = "Nombre";
            cmbCategoria.ValueMember = "Id";
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (cmbCategoria.SelectedItem is Categoria categoria)
            {
                dgvProductos.DataSource = null;
                dgvProductos.DataSource = _ventaNegocio.ObtenerProductosPorCategoria(categoria.Id);
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (dgvProductos.SelectedRows.Count == 0)
                return;

            foreach (DataGridViewRow row in dgvProductos.SelectedRows)
            {
                if (row.DataBoundItem is Producto producto)
                {
                    ProductosSeleccionados.Add(new ItemVenta
                    {
                        Producto = producto,
                        Cantidad = 1
                    });
                }
            }

            DialogResult = DialogResult.OK;
            Close();
        }
    }

    public class Categoria
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
    }
}
