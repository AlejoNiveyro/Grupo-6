﻿using System;

namespace Entidades
{
    public class Usuario
    {
        public int Legajo { get; set; }
        public string NombreUsuario { get; set; } 
        public string Clave { get; set; }
        public bool Bloqueado { get; set; }
        public int IntentosFallidos { get; set; }
        public bool RequiereCambioClave { get; set; }
        public DateTime? FechaUltimoLogin { get; set; }
        public DateTime? FechaUltimoCambioClave { get; set; }
        public string Perfil { get; set; }
    }
}
