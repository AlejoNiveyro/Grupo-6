﻿using Datos;
using Entidades;
using System.Collections.Generic;

namespace Negocio
{
    public class PersonaNegocio
    {
        public List<Persona> ObtenerTodos()
        {
            return PersonaDatos.ObtenerPersonas();
        }

        public void ModificarPersona(Persona personaModificada)
        {
            var personas = PersonaDatos.ObtenerPersonas();
            for (int i = 0; i < personas.Count; i++)
            {
                if (personas[i].Legajo == personaModificada.Legajo)
                {
                    personas[i] = personaModificada;
                    break;
                }
            }
            PersonaDatos.GuardarPersonas(personas);
        }

        public void ModificarPersonaDesdeLista(List<Persona> personas)
        {
            PersonaDatos.GuardarPersonas(personas);
        }
    }
}
