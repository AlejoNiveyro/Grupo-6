﻿// Clase negocio actual
using Datos.Login;
using Persistencia;

namespace Negocio
{
    public class LoginNegocio
    {
        public bool Autenticar(string usuario, string password, out string mensaje)
        {
            if (UsuarioPersistencia.EstaBloqueado(usuario))
            {
                mensaje = "Usuario bloqueado por intentos fallidos.";
                return false;
            }

            var credencial = UsuarioPersistencia.ObtenerCredencial(usuario);
            if (credencial == null)
            {
                UsuarioPersistencia.RegistrarIntento(usuario, false);
                mensaje = "Usuario no encontrado.";
                return false;
            }

            if (credencial.Password != password)
            {
                UsuarioPersistencia.RegistrarIntento(usuario, false);
                mensaje = "Contraseña incorrecta.";
                return false;
            }

            UsuarioPersistencia.RegistrarIntento(usuario, true);
            mensaje = "Login exitoso.";
            return true;
        }
    }
}
