﻿using System;
using System.Windows.Forms;
using Negocio;
using Entidades;

namespace TPCai
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string usuarioIngresado = txtUsuario.Text.Trim();
            string claveIngresada = txtClave.Text.Trim();

            var loginNegocio = new LoginNegocio();
            var resultado = loginNegocio.Autenticar(usuarioIngresado, claveIngresada, out string mensaje);

            if (!resultado.Autenticado)
            {
                MessageBox.Show(resultado.Mensaje, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MessageBox.Show($"Bienvenido {resultado.UsuarioAutenticado.NombreUsuario}\nPerfil: {resultado.Perfil}",
                "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Continuar al menú
            this.Hide();
            FormMenu menu = new FormMenu(resultado.UsuarioAutenticado);
            menu.Show();
        }
    }
}
