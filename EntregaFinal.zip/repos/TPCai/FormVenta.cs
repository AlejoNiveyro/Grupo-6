﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Entidades;
using Negocio;

namespace TPCai
{
    public partial class FormVenta : Form
    {
        private Carrito _carrito = new Carrito();
        private VentaNegocio _ventaNegocio = new VentaNegocio();
        private List<Cliente> _clientes;

        public FormVenta()
        {
            InitializeComponent();
        }

        private void FormVenta_Load(object sender, EventArgs e)
        {
            _clientes = _ventaNegocio.ObtenerClientes();
            cmbClientes.DataSource = _clientes;
            cmbClientes.DisplayMember = "Nombre";
            cmbClientes.ValueMember = "Id";
            RefrescarCarrito();
        }

        private void RefrescarCarrito()
        {
            dgvCarrito.DataSource = null;
            dgvCarrito.DataSource = _carrito.Items.Select(i => new
            {
                i.Producto.ProductoId,
                i.Producto.Nombre,
                i.Producto.Categoria,
                i.Producto.Precio,
                i.Cantidad,
                i.Subtotal
            }).ToList();

            lblSubtotal.Text = _carrito.CalcularSubtotal().ToString("C");
            lblDescuento.Text = _carrito.CalcularDescuento().ToString("C");
            lblTotal.Text = _carrito.CalcularTotal().ToString("C");
        }

        private void btnAgregarProducto_Click(object sender, EventArgs e)
        {
            var formSeleccion = new FormSeleccionarProducto();
            if (formSeleccion.ShowDialog() == DialogResult.OK)
            {
                foreach (var item in formSeleccion.ProductosSeleccionados)
                {
                    _carrito.Agregar(item);
                }
                RefrescarCarrito();
            }
        }

        private void btnQuitarProducto_Click(object sender, EventArgs e)
        {
            if (dgvCarrito.CurrentRow != null)
            {
                int prodId = (int)dgvCarrito.CurrentRow.Cells["ProductoId"].Value;
                _carrito.Quitar(prodId);
                RefrescarCarrito();
            }
        }

        private void btnProcesarVenta_Click(object sender, EventArgs e)
        {
            if (_carrito.Items.Count == 0)
            {
                MessageBox.Show("Debe agregar productos.");
                return;
            }

            if (cmbClientes.SelectedItem is Cliente cliente)
            {
                _ventaNegocio.ProcesarVenta(cliente.Id, _carrito);
                MessageBox.Show("Venta procesada correctamente.");
                this.Close();
            }
            else
            {
                MessageBox.Show("Seleccione un cliente.");
            }
        }
    }
}
