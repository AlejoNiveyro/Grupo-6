﻿using System.Collections.Generic;
using System.Linq;

namespace Entidades
{
    public class Carrito
    {
        public List<ItemVenta> Items { get; set; } = new List<ItemVenta>();

        public void Agregar(Producto producto, int cantidad)
        {
            var item = Items.FirstOrDefault(x => x.Producto.ProductoId == producto.ProductoId);
            if (item != null)
                item.Cantidad += cantidad;
            else
                Items.Add(new ItemVenta { Producto = producto, Cantidad = cantidad });
        }

        public void Quitar(int productoId)
        {
            Items.RemoveAll(x => x.Producto.ProductoId == productoId);
        }

        public decimal CalcularSubtotal() => Items.Sum(x => x.Subtotal);

        public decimal CalcularDescuento()
        {
            var subtotal = CalcularSubtotal();
            var tieneElectroHogar = Items.Any(i => i.Producto.Categoria == 3);
            return (subtotal > 1_000_000 && tieneElectroHogar) ? subtotal * 0.15m : 0m;
        }
        public void Agregar(ItemVenta item)
        {
            var existente = Items.FirstOrDefault(i => i.Producto.ProductoId == item.Producto.ProductoId);
            if (existente != null)
            {
                existente.Cantidad += item.Cantidad;
            }
            else
            {
                Items.Add(item);
            }
        }

        public decimal CalcularTotal() => CalcularSubtotal() - CalcularDescuento();
    }
}
