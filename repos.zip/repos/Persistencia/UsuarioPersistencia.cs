﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Datos.Login;

namespace Persistencia
{
    public class UsuarioPersistencia
    {
        private static string BasePath = AppDomain.CurrentDomain.BaseDirectory;

        private static string credencialesPath = Path.Combine(BasePath, "DataBase", "Tablas", "credenciales.csv");
        private static string intentosPath = Path.Combine(BasePath, "DataBase", "Tablas", "login_intentos.csv");
        private static string bloqueadosPath = Path.Combine(BasePath, "DataBase", "Tablas", "usuario_bloqueado.csv");
        private const int MaxIntentos = 3;

        public static Credencial ObtenerCredencial(string usuario)
        {
            if (!File.Exists(credencialesPath)) return null;

            var lines = File.ReadAllLines(credencialesPath);
            foreach (var line in lines)
            {
                var parts = line.Split(',');
                if (parts.Length >= 2 && parts[0].Trim() == usuario)
                {
                    return new Credencial
                    {
                        Usuario = parts[0].Trim(),
                        Password = parts[1].Trim()
                    };
                }
            }
            return null;
        }

        public static bool EstaBloqueado(string usuario)
        {
            if (!File.Exists(bloqueadosPath)) return false;
            return File.ReadAllLines(bloqueadosPath)
                       .Any(line => line.Trim().Equals(usuario, StringComparison.OrdinalIgnoreCase));
        }

        public static void RegistrarIntento(string usuario, bool exitoso)
        {
            EnsureFolderExists(intentosPath);
            EnsureFolderExists(bloqueadosPath);

            if (exitoso)
            {
                var intentos = File.Exists(intentosPath)
                    ? File.ReadAllLines(intentosPath).ToList()
                    : new List<string>();

                intentos.RemoveAll(l => l.StartsWith(usuario + ","));
                File.WriteAllLines(intentosPath, intentos);
            }
            else
            {
                var intentos = File.Exists(intentosPath)
                    ? File.ReadAllLines(intentosPath).ToList()
                    : new List<string>();

                int actuales = 0;
                var linea = intentos.FirstOrDefault(l => l.StartsWith(usuario + ","));
                if (linea != null)
                {
                    actuales = int.Parse(linea.Split(',')[1]);
                    intentos.Remove(linea);
                }

                actuales += 1;
                intentos.Add($"{usuario},{actuales}");
                File.WriteAllLines(intentosPath, intentos);

                if (actuales >= MaxIntentos)
                {
                    var bloqueados = File.Exists(bloqueadosPath)
                        ? File.ReadAllLines(bloqueadosPath).ToList()
                        : new List<string>();
                    bloqueados.Add(usuario);
                    File.WriteAllLines(bloqueadosPath, bloqueados);
                }
            }
        }

        private static void EnsureFolderExists(string path)
        {
            var dir = Path.GetDirectoryName(path);
            if (!Directory.Exists(dir))
                Directory.CreateDirectory(dir);
        }
    }
}
