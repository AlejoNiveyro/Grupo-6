﻿using System;
using System.Windows.Forms;
using Persistencia;

namespace TPCai
{
    public partial class FormCambiarClave : Form
    {
        private string _usuario;

        public FormCambiarClave(string usuario)
        {
            InitializeComponent();
            _usuario = usuario;
        }

        private void btnCambiarClave_Click(object sender, EventArgs e)
        {
            string claveActual = txtClaveActual.Text.Trim();
            string nuevaClave = txtNuevaClave.Text.Trim();

            var usuarioObj = UsuarioPersistencia.ObtenerUsuario(_usuario);

            if (usuarioObj == null)
            {
                MessageBox.Show("Usuario no encontrado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (usuarioObj.Clave != claveActual)
            {
                MessageBox.Show("La clave actual no es correcta.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(nuevaClave) || nuevaClave.Length < 8)
            {
                MessageBox.Show("La nueva clave debe tener al menos 8 caracteres.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            UsuarioPersistencia.CambiarClave(_usuario, nuevaClave);

            MessageBox.Show("Clave actualizada exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }
    }
}
