﻿using System;
using System.IO;
using System.Windows.Forms;
using Negocio;

namespace TPCai
{
    public partial class FormDesbloquearUsuario : Form
    {
        private readonly UsuarioNegocio _usuarioNegocio;

        public FormDesbloquearUsuario()
        {
            InitializeComponent();
            _usuarioNegocio = new UsuarioNegocio();
        }

        private void FormDesbloquearUsuario_Load(object sender, EventArgs e)
        {
            try
            {
                string basePath = AppDomain.CurrentDomain.BaseDirectory;
                string bloqueadosPath = Path.Combine(basePath, "Database", "Table", "usuario_bloqueado.csv");

                if (!File.Exists(bloqueadosPath))
                {
                    MessageBox.Show("No se encontró el archivo de usuarios bloqueados.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var usuarios = File.ReadAllLines(bloqueadosPath);
                cmbUsuarios.Items.Clear();
                foreach (var usuario in usuarios)
                {
                    cmbUsuarios.Items.Add(usuario.Trim());
                }

                if (cmbUsuarios.Items.Count > 0)
                {
                    cmbUsuarios.SelectedIndex = 0;
                }
                else
                {
                    MessageBox.Show("No hay usuarios bloqueados.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar usuarios bloqueados: " + ex.Message);
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (cmbUsuarios.SelectedItem == null)
            {
                MessageBox.Show("Debe seleccionar un usuario.");
                return;
            }

            string usuario = cmbUsuarios.SelectedItem.ToString();
            string nuevaClave = txtNuevaClave.Text.Trim();

            if (string.IsNullOrEmpty(nuevaClave))
            {
                MessageBox.Show("Debe ingresar la nueva clave.");
                return;
            }

            if (nuevaClave.Length < 8)
            {
                MessageBox.Show("La clave debe tener al menos 8 caracteres.");
                return;
            }

            try
            {
                _usuarioNegocio.CambiarClave(usuario, nuevaClave);
                _usuarioNegocio.DesbloquearUsuario(usuario);
                _usuarioNegocio.MarcarCambioClaveObligatorio(usuario);

                MessageBox.Show("Usuario actualizado y desbloqueado correctamente.");

                cmbUsuarios.Items.Remove(usuario);
                txtNuevaClave.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
