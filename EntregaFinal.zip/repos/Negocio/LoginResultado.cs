﻿using Entidades;

namespace Negocio
{
    public class LoginResultado
    {
        public bool Autenticado { get; set; }
        public string Mensaje { get; set; }
        public string Perfil { get; set; }
        public Usuario UsuarioAutenticado { get; set; }

    }
}

