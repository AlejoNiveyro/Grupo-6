﻿


namespace Datos.Login
{
    public class Credencial
    {
        public string Usuario { get; set; }
        public string Password { get; set; }
    }
}
