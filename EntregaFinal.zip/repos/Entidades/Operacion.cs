﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Entidades
{
    public class Operacion
    {
        public int Id { get; set; }
        public string Tipo { get; set; }
        public string UsuarioObjetivo { get; set; }
        public string DatosNuevos { get; set; }
        public bool Aprobada { get; set; }

        public void AprobarOperacion(Operacion op)
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Database", "Tablas", "autorizacion.csv");
            if (!File.Exists(path)) return;

            var lineas = File.ReadAllLines(path);
            var nuevasLineas = new List<string>();

            foreach (var linea in lineas)
            {
                var partes = linea.Split(';');
                if (int.TryParse(partes[0], out int id) && id == op.Id)
                {
                    partes[4] = "true";
                    nuevasLineas.Add(string.Join(";", partes));
                }
                else
                {
                    nuevasLineas.Add(linea);
                }
            }

            File.WriteAllLines(path, nuevasLineas);
        }

        public List<Operacion> ObtenerPendientes()
        {
            List<Operacion> pendientes = new List<Operacion>();

            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Database", "Tablas", "autorizacion.csv");
            if (!File.Exists(path)) return pendientes;

            var lineas = File.ReadAllLines(path);
            foreach (var linea in lineas)
            {
                var partes = linea.Split(';');
                if (partes.Length >= 5 && partes[4].Trim().ToLower() == "false")
                {
                    pendientes.Add(new Operacion
                    {
                        Id = int.Parse(partes[0]),
                        Tipo = partes[1],
                        UsuarioObjetivo = partes[2],
                        DatosNuevos = partes[3],
                        Aprobada = false
                    });
                }
            }

            return pendientes;
        }
    }
}
