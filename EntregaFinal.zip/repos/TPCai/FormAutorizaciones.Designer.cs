﻿namespace TPCai
{
    partial class FormAutorizaciones
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvOps;
        private System.Windows.Forms.Button btnAprobar;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvOps = new System.Windows.Forms.DataGridView();
            this.btnAprobar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOps)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvOps
            // 
            this.dgvOps.AllowUserToAddRows = false;
            this.dgvOps.AllowUserToDeleteRows = false;
            this.dgvOps.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvOps.Location = new System.Drawing.Point(12, 12);
            this.dgvOps.MultiSelect = false;
            this.dgvOps.Name = "dgvOps";
            this.dgvOps.ReadOnly = true;
            this.dgvOps.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvOps.Size = new System.Drawing.Size(560, 300);
            this.dgvOps.TabIndex = 0;
            // 
            // btnAprobar
            // 
            this.btnAprobar.Location = new System.Drawing.Point(497, 325);
            this.btnAprobar.Name = "btnAprobar";
            this.btnAprobar.Size = new System.Drawing.Size(75, 23);
            this.btnAprobar.TabIndex = 1;
            this.btnAprobar.Text = "Aprobar";
            this.btnAprobar.UseVisualStyleBackColor = true;
            this.btnAprobar.Click += new System.EventHandler(this.btnAprobar_Click);
            // 
            // FormAutorizaciones
            // 
            this.ClientSize = new System.Drawing.Size(584, 361);
            this.Controls.Add(this.btnAprobar);
            this.Controls.Add(this.dgvOps);
            this.Name = "FormAutorizaciones";
            this.Text = "Autorizaciones";
            this.Load += new System.EventHandler(this.FormAutorizaciones_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOps)).EndInit();
            this.ResumeLayout(false);
        }
    }
}
