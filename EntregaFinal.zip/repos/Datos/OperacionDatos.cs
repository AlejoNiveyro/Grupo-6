﻿using Entidades;
using System.Collections.Generic;
using System.IO;

namespace Datos
{
    public class OperacionDatos
    {
        private static string archivoOps = "operaciones.csv";

        public static List<Operacion> ObtenerOperaciones()
        {
            var lista = new List<Operacion>();
            if (!File.Exists(archivoOps)) return lista;

            foreach (var linea in File.ReadAllLines(archivoOps))
            {
                if (string.IsNullOrWhiteSpace(linea)) continue;
                var p = linea.Split(',');
                lista.Add(new Operacion
                {
                    Id = int.Parse(p[0]),
                    Tipo = p[1],               
                    UsuarioObjetivo = p[2],
                    DatosNuevos = p[3],
                    Aprobada = bool.Parse(p[4])
                });
            }
            return lista;
        }

        public static void GuardarOperaciones(List<Operacion> ops)
        {
            using (var writer = new StreamWriter(archivoOps, false))
            {
                foreach (var o in ops)
                    writer.WriteLine($"{o.Id},{o.Tipo},{o.UsuarioObjetivo},{o.DatosNuevos},{o.Aprobada}");
            }
        }

    }
}
