﻿using System;

namespace Datos.Login
{
    public class Credencial
    {
        public string Usuario { get; set; }
        public string Password { get; set; }

        public DateTime? FechaUltimoCambioClave { get; set; }
        public bool RequiereCambioClave { get; set; }
        public DateTime? FechaUltimoLogin { get; set; }
    }
}
