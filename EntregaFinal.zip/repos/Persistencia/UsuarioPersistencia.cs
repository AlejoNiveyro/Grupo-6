﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Entidades;

namespace Persistencia
{
    public class UsuarioPersistencia
    {
        private static string BasePath = AppDomain.CurrentDomain.BaseDirectory;
        private static string credencialesPath = Path.Combine(BasePath, "Database", "Tablas", "credenciales.csv");
        private static string intentosPath = Path.Combine(BasePath, "Database", "Tablas", "login_intentos.csv");
        private static string bloqueadosPath = Path.Combine(BasePath, "Database", "Tablas", "usuario_bloqueado.csv");
        private static string requerirClavePath = Path.Combine(BasePath, "Database", "Tablas", "requerir_cambio_clave.csv");


        private const int MaxIntentos = 3;

        public static Usuario ObtenerUsuario(string nombreUsuario)
        {
            if (!File.Exists(credencialesPath)) return null;

            var lineas = File.ReadAllLines(credencialesPath);
            foreach (var linea in lineas)
            {
                var partes = linea.Split(';');

                if (partes[1].Trim().Equals(nombreUsuario, StringComparison.OrdinalIgnoreCase))
                {
                    bool requiereCambio = File.Exists(requerirClavePath) &&
                        File.ReadAllLines(requerirClavePath).Any(x => x.Trim().Equals(nombreUsuario, StringComparison.OrdinalIgnoreCase));

                    return new Usuario
                    {
                        Legajo = int.TryParse(partes[0], out var legajo) ? legajo : 0,
                        NombreUsuario = partes[1].Trim(),
                        Clave = partes[2].Trim(),
                        FechaUltimoCambioClave = DateTime.TryParse(partes.Length > 3 ? partes[3] : null, out var fechaCambio) ? fechaCambio : (DateTime?)null,
                        FechaUltimoLogin = DateTime.TryParse(partes.Length > 4 ? partes[4] : null, out var fechaLogin) ? fechaLogin : (DateTime?)null,
                        RequiereCambioClave = requiereCambio,
                        Bloqueado = EstaBloqueado(partes[1].Trim()),
                        IntentosFallidos = ObtenerIntentosFallidos(partes[1].Trim()),
                        Perfil = ObtenerPerfil(partes[0]) 
                    };
                }
            }

            return null;
        }
        public static string ObtenerPerfilPorLegajo(int legajo)
        {
            string perfilPath = Path.Combine(BasePath, "Database", "Tablas", "usuario_perfil.csv");
            string usuarioPerfilPath = Path.Combine(BasePath, "Database", "Tablas", "perfil.csv");


            if (!File.Exists(usuarioPerfilPath) || !File.Exists(perfilPath))
                return "Perfil no encontrado";

            
            string idPerfil = File.ReadAllLines(usuarioPerfilPath)
                .Select(line => line.Split(';'))
                .FirstOrDefault(parts => parts[0] == legajo.ToString())?[1];

            if (string.IsNullOrWhiteSpace(idPerfil))
                return "Perfil no encontrado";

            
            string nombrePerfil = File.ReadAllLines(perfilPath)
                .Select(line => line.Split(';'))
                .FirstOrDefault(parts => parts[0] == idPerfil)?[1];

            return nombrePerfil ?? "Perfil no encontrado";
        }

        public static bool EstaBloqueado(string usuario)
        {
            if (!File.Exists(bloqueadosPath)) return false;
            return File.ReadAllLines(bloqueadosPath)
                       .Any(line => line.Trim().Equals(usuario, StringComparison.OrdinalIgnoreCase));
        }

        public static int ObtenerIntentosFallidos(string usuario)
        {
            if (!File.Exists(intentosPath)) return 0;

            var linea = File.ReadAllLines(intentosPath)
                            .FirstOrDefault(x => x.StartsWith(usuario + ";"));

            if (linea != null && int.TryParse(linea.Split(';')[1], out int intentos))
                return intentos;

            return 0;
        }

        public static void RegistrarIntentoFallido(string usuario)
        {
            if (!File.Exists(intentosPath)) File.WriteAllText(intentosPath, "");
            var intentos = File.ReadAllLines(intentosPath).ToList();

            int actuales = 0;
            var existente = intentos.FirstOrDefault(x => x.StartsWith(usuario + ";"));
            if (existente != null)
            {
                actuales = int.Parse(existente.Split(';')[1]);
                intentos.Remove(existente);
            }

            actuales++;
            intentos.Add($"{usuario};{actuales}");
            File.WriteAllLines(intentosPath, intentos);

            if (actuales >= MaxIntentos)
            {
                BloquearUsuario(usuario);
            }
        }

        public static void BloquearUsuario(string usuario)
        {
            var bloqueados = File.Exists(bloqueadosPath)
                ? File.ReadAllLines(bloqueadosPath).ToList()
                : new List<string>();

            if (!bloqueados.Contains(usuario))
            {
                bloqueados.Add(usuario);
                File.WriteAllLines(bloqueadosPath, bloqueados);
            }
        }

        public static void DesbloquearUsuario(string usuario)
        {
            if (File.Exists(bloqueadosPath))
            {
                var bloqueados = File.ReadAllLines(bloqueadosPath).ToList();
                bloqueados.RemoveAll(x => x.Trim().Equals(usuario, StringComparison.OrdinalIgnoreCase));
                File.WriteAllLines(bloqueadosPath, bloqueados);
            }

            if (File.Exists(intentosPath))
            {
                var intentos = File.ReadAllLines(intentosPath).ToList();
                intentos.RemoveAll(x => x.StartsWith(usuario + ";"));
                File.WriteAllLines(intentosPath, intentos);
            }
        }

        public static void CambiarClave(string nombreUsuario, string nuevaClave)
        {
            if (!File.Exists(credencialesPath)) return;

            var lineas = File.ReadAllLines(credencialesPath).ToList();
            for (int i = 0; i < lineas.Count; i++)
            {
                var partes = lineas[i].Split(';');
                if (partes[1].Trim().Equals(nombreUsuario, StringComparison.OrdinalIgnoreCase))
                {
                    partes[2] = nuevaClave;
                    if (partes.Length < 5) Array.Resize(ref partes, 5);
                    partes[3] = DateTime.Now.ToString("dd/MM/yyyy"); 
                    lineas[i] = string.Join(";", partes);
                    break;
                }
            }

            File.WriteAllLines(credencialesPath, lineas);

            if (File.Exists(requerirClavePath))
            {
                var requerir = File.ReadAllLines(requerirClavePath).ToList();
                requerir.RemoveAll(x => x.Trim().Equals(nombreUsuario, StringComparison.OrdinalIgnoreCase));
                File.WriteAllLines(requerirClavePath, requerir);
            }
        }

        public static void ActualizarFechaUltimoLogin(string nombreUsuario, DateTime now)
        {
            if (!File.Exists(credencialesPath)) return;

            var lineas = File.ReadAllLines(credencialesPath).ToList();
            for (int i = 0; i < lineas.Count; i++)
            {
                var partes = lineas[i].Split(';');
                if (partes[1].Trim().Equals(nombreUsuario, StringComparison.OrdinalIgnoreCase))
                {
                    if (partes.Length < 5) Array.Resize(ref partes, 5);
                    partes[4] = DateTime.Now.ToString("dd/MM/yyyy"); 
                    lineas[i] = string.Join(";", partes);
                    break;
                }
            }

            File.WriteAllLines(credencialesPath, lineas);
        }

        public static void MarcarClaveComoRequerida(string nombreUsuario)
        {
            var lista = File.Exists(requerirClavePath)
                ? File.ReadAllLines(requerirClavePath).ToList()
                : new List<string>();

            if (!lista.Contains(nombreUsuario))
            {
                lista.Add(nombreUsuario);
                File.WriteAllLines(requerirClavePath, lista);
            }
        }

        public static string ObtenerPerfil(string legajo)
        {
            string path = Path.Combine(BasePath, "Database", "Tablas", "usuario_perfil.csv");
            string perfilPath = Path.Combine(BasePath, "Database", "Tablas", "perfil.csv");

            if (!File.Exists(path) || !File.Exists(perfilPath)) return "";

            var lineas = File.ReadAllLines(path);
            foreach (var linea in lineas)
            {
                var partes = linea.Split(';');
                if (partes[0].Trim() == legajo)
                {
                    string idPerfil = partes[1].Trim();

                    // Buscar nombre del perfil
                    var perfiles = File.ReadAllLines(perfilPath);
                    foreach (var perfilLinea in perfiles)
                    {
                        var perfilPartes = perfilLinea.Split(';');
                        if (perfilPartes[0].Trim() == idPerfil)
                        {
                            return perfilPartes[1].Trim();
                        }
                    }
                }
            }

            return "";
        }
    }
}
