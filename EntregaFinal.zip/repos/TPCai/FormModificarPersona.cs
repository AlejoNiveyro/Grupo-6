﻿using Entidades;
using Negocio;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace TPCai
{
    public partial class FormModificarPersona : Form
    {
        private PersonaNegocio _negocio;
        private List<Persona> _personas;

        public FormModificarPersona()
        {
            InitializeComponent();
            _negocio = new PersonaNegocio();
        }

        private void FormModificarPersona_Load(object sender, EventArgs e)
        {
            _personas = _negocio.ObtenerTodos();
            dgvPersonas.DataSource = _personas;

            dgvPersonas.Columns["Legajo"].ReadOnly = true;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            _negocio.ModificarPersonaDesdeLista((List<Persona>)dgvPersonas.DataSource);
            MessageBox.Show("Cambios guardados correctamente");
        }
    }
}
