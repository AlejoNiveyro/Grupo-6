﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System;
using System.Windows.Forms;
using Negocio;

namespace TPCai
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text.Trim();
            string clave = txtClave.Text.Trim();

            var login = new LoginNegocio();
            if (login.Autenticar(usuario, clave, out string mensaje))
            {
                MessageBox.Show(mensaje, "Acceso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show(mensaje, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

