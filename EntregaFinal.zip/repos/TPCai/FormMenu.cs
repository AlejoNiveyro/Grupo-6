﻿using System;
using System.Windows.Forms;
using Entidades;

namespace TPCai
{
    public partial class FormMenu : Form
    {
        private Usuario _usuario;

        public FormMenu(Usuario usuario)
        {
            InitializeComponent();
            _usuario = usuario;
        }


        private void FormMenu_Load(object sender, EventArgs e)
        {
            lblBienvenida.Text = $"Bienvenido {_usuario.NombreUsuario} - Perfil: {_usuario.Perfil}";

            if (_usuario.Perfil == "Supervisor")
            {
                btnModificarPersona.Visible = true;
                btnDesbloquearUsuario.Visible = true;
                btnAutorizaciones.Visible = false;
                btnVenta.Visible = false;
            }
            else if (_usuario.Perfil == "Administrador")
            {
                btnAutorizaciones.Visible = true;
                btnModificarPersona.Visible = false;
                btnDesbloquearUsuario.Visible = false;
                btnVenta.Visible = false;
            }
            else if (_usuario.Perfil == "Operador")
            {
                btnModificarPersona.Visible = false;
                btnDesbloquearUsuario.Visible = false;
                btnAutorizaciones.Visible = false;
                btnVenta.Visible = true;
            }
        }


        private void btnModificarPersona_Click(object sender, EventArgs e)
        {
            FormModificarPersona form = new FormModificarPersona();
            form.ShowDialog();
        }

        private void btnDesbloquearUsuario_Click(object sender, EventArgs e)
        {
            FormDesbloquearUsuario form = new FormDesbloquearUsuario();
            form.ShowDialog();
        }

        private void btnAutorizaciones_Click(object sender, EventArgs e)
        {
            FormAutorizaciones form = new FormAutorizaciones();
            form.ShowDialog();
        }
        private void btnVenta_Click(object sender, EventArgs e)
        {
            FormVenta venta = new FormVenta();
            venta.ShowDialog();
        }

    }
}
