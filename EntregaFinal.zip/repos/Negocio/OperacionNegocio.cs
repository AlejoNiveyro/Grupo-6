﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Entidades;
using Persistencia;

namespace Negocio
{
    public class OperacionNegocio
    {
        private static string basePath = AppDomain.CurrentDomain.BaseDirectory;
        private static string operacionPath = Path.Combine(basePath, "Database", "operacion.csv");
        private static string autorizacionPath = Path.Combine(basePath, "Database", "autorizacion.csv");

        public void DesbloquearCredencial(string usuario)
        {
            UsuarioPersistencia.DesbloquearUsuario(usuario);
        }

        public void CambiarClave(string usuario, string nuevaClave)
        {
            UsuarioPersistencia.CambiarClave(usuario, nuevaClave);
            UsuarioPersistencia.ActualizarFechaUltimoLogin(usuario, DateTime.Now);
        }

        public void ForzarCambioClave(string usuario)
        {
            UsuarioPersistencia.MarcarClaveComoRequerida(usuario);
        }

        public void RegistrarLogin(string usuario)
        {
            UsuarioPersistencia.ActualizarFechaUltimoLogin(usuario, DateTime.Now);
        }

        public List<Operacion> ObtenerPendientes()
        {
            var pendientes = new List<Operacion>();

            if (!File.Exists(operacionPath)) return pendientes;

            var lineas = File.ReadAllLines(operacionPath);
            foreach (var linea in lineas)
            {
                var partes = linea.Split(';');
                if (partes.Length >= 4 && partes[4] == "false")
                {
                    pendientes.Add(new Operacion
                    {
                        Id = int.Parse(partes[0]),
                        Tipo = partes[1],
                        UsuarioObjetivo = partes[2],
                        DatosNuevos = partes[3],
                        Aprobada = false
                    });
                }
            }

            return pendientes;
        }

        public void AprobarOperacion(Operacion op)
        {
            if (!File.Exists(operacionPath)) return;

            var lineas = File.ReadAllLines(operacionPath).ToList();

            for (int i = 0; i < lineas.Count; i++)
            {
                var partes = lineas[i].Split(';');
                if (int.Parse(partes[0]) == op.Id)
                {
                    partes[4] = "true";
                    lineas[i] = string.Join(";", partes);
                    break;
                }
            }

            File.WriteAllLines(operacionPath, lineas);

            // Registrar autorización
            var nuevaLinea = $"{op.Id};{op.Tipo};{op.UsuarioObjetivo};{op.DatosNuevos};true";
            File.AppendAllText(autorizacionPath, nuevaLinea + Environment.NewLine);
        }
    }
}
