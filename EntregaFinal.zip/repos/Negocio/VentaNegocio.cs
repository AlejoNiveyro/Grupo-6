﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using Entidades;

namespace Negocio
{
    public class VentaNegocio
    {
        private readonly string clientesPath = Path.Combine("Database", "Tablas","clientes.csv");
        private readonly string productosPath = Path.Combine("Database", "Tablas", "productos.csv");

        public List<Cliente> ObtenerClientes()
        {
            var clientes = new List<Cliente>();

            if (!File.Exists(clientesPath)) return clientes;

            foreach (var line in File.ReadAllLines(clientesPath).Skip(1))
            {
                var parts = line.Split(';');
                var cliente = new Cliente
                {
                    Id = int.Parse(parts[0]),
                    Nombre = parts[1],
                    Apellido = parts[2]
                };
                clientes.Add(cliente);
            }

            return clientes;
        }


        public List<Producto> ObtenerProductosPorCategoria(int categoria)
        {
            List<Producto> list = new List<Producto>();
            if (!File.Exists(productosPath))
            {
                return list;
            }

            foreach (string item in File.ReadAllLines(productosPath).Skip(1))
            {
                string[] array = item.Split(';');

                if (array.Length < 4)
                    continue;

                if (int.TryParse(array[2], out var result) && result == categoria)
                {
                    list.Add(new Producto
                    {
                        ProductoId = int.Parse(array[0]),
                        Nombre = array[1],
                        Categoria = result,
                        Precio = decimal.Parse(array[3])
                    });
                }
            }

            return list;
        }


        public void ProcesarVenta(int clienteId, Carrito carrito)
        {
            string ruta = "ventas_simuladas.txt";
            string linea = "Cliente " + clienteId.ToString() + ": Total $" + carrito.CalcularTotal().ToString("N2") + "\n";
            File.AppendAllText(ruta, linea);
        }

    }
}
