﻿namespace Entidades
{
    public class Credencial
    {
        public int Legajo { get; set; }
        public string Usuario { get; set; }
        public string Password { get; set; }
        public string Perfil { get; set; }
    }
}

