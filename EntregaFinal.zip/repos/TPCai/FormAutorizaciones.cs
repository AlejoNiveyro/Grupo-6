﻿using Entidades;
using Negocio;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace TPCai
{
    public partial class FormAutorizaciones : Form
    {
        private readonly Operacion _neg;
        private List<Operacion> _pendientes;

        public FormAutorizaciones()
        {
            InitializeComponent();
            _neg = new Operacion();
        }

        private void FormAutorizaciones_Load(object sender, EventArgs e)
        {
            CargarGrid();
        }

        private void CargarGrid()
        {
            _pendientes = _neg.ObtenerPendientes();
            dgvOps.DataSource = null;
            dgvOps.DataSource = _pendientes;
            dgvOps.Columns["DatosNuevos"].HeaderText = "Datos Nuevos";
            dgvOps.Columns["Aprobada"].Visible = false;
        }


        private void btnAprobar_Click(object sender, EventArgs e)
        {
            if (dgvOps.SelectedRows.Count > 0)
            {
                var operacion = dgvOps.SelectedRows[0].DataBoundItem as Operacion;

                if (operacion != null)
                {
                    OperacionNegocio opNeg = new OperacionNegocio();
                    opNeg.AprobarOperacion(operacion);

                    MessageBox.Show("Operación aprobada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    
                    CargarGrid();
                }
            }
            else
            {
                MessageBox.Show("Seleccioná una operación para aprobar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

    }
}
