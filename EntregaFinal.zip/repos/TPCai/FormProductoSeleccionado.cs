﻿using System;
using System.Windows.Forms;
using Entidades;

namespace TPCai
{
    public partial class FormProductoSeleccionado : Form
    {
        private Producto _producto;

        public FormProductoSeleccionado(Producto producto)
        {
            InitializeComponent();
            _producto = producto;
        }

        private void FormProductoSeleccionado_Load(object sender, EventArgs e)
        {
            txtId.Text = _producto.ProductoId.ToString();
            txtNombre.Text = _producto.Nombre;
            txtPrecio.Text = _producto.Precio.ToString("C");
            chkDisponible.Checked = _producto.Disponible;
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
