﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Entidades;
using Negocio;


namespace TPCai
{
    public partial class FormListadoProductos : Form
    {
        private ProductoNegocio _productoNegocio = new ProductoNegocio();
        private List<Producto> _productos;

        public FormListadoProductos()
        {
            InitializeComponent();
            CargarProductos();
        }

        private void CargarProductos()
        {
            _productos = _productoNegocio.ObtenerProductos();
            dgvProductos.DataSource = null;
            dgvProductos.DataSource = _productos;
        }

        private void btnSeleccionar_Click(object sender, EventArgs e)
        {
            AbrirProductoSeleccionado();
        }

        private void dgvProductos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            AbrirProductoSeleccionado();
        }

        private void AbrirProductoSeleccionado()
        {
            if (dgvProductos.CurrentRow != null)
            {
                Producto productoSeleccionado = dgvProductos.CurrentRow.DataBoundItem as Producto;
                if (productoSeleccionado != null)
                {
                    FormProductoSeleccionado detalle = new FormProductoSeleccionado(productoSeleccionado);
                    detalle.ShowDialog();
                }
            }
        }
    }
}
