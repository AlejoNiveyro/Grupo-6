﻿using System;
using System.Collections.Generic;
using System.IO;
using Entidades;

namespace Datos
{
    public class PersonaDatos
    {
        private static string archivo = "personas.csv";

        public static List<Persona> ObtenerPersonas()
        {
            var lista = new List<Persona>();
            if (!File.Exists(archivo)) return lista;

            foreach (var linea in File.ReadAllLines(archivo))
            {
                var partes = linea.Split(',');
                lista.Add(new Persona
                {
                    Legajo = int.Parse(partes[0]),
                    Nombre = partes[1],
                    Apellido = partes[2],
                    Email = partes[3],
                    FechaNacimiento = DateTime.Parse(partes[4])
                });
            }

            return lista;
        }

        public static void GuardarPersonas(List<Persona> personas)
        {
            using (var writer = new StreamWriter(archivo, false))
            {
                foreach (var p in personas)
                {
                    writer.WriteLine($"{p.Legajo},{p.Nombre},{p.Apellido},{p.Email},{p.FechaNacimiento:yyyy-MM-dd}");
                }
            }
        }
    }
}
