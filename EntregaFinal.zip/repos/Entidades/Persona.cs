﻿using System;

namespace Entidades
{
    public class Persona
    {
        public int Legajo { get; set; } 
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Email { get; set; }
        public DateTime FechaNacimiento { get; set; }
    }
}
