﻿using Entidades;
using Persistencia;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Negocio
{
    public class ProductoNegocio
    {
        private readonly ProductoPersistencia _repo;

        public ProductoNegocio()
        {
            _repo = new ProductoPersistencia();
        }

        public List<Producto> ObtenerProductos()
        {
            throw new NotImplementedException();
        }

        public object ObtenerProductosDisponibles()
        {
            throw new NotImplementedException();
        }

        public List<Producto> TraerProductosPorCategoria(int categoria) =>
            _repo.CargarTodos()
                 .Where(p => p.Categoria == categoria)
                 .ToList();
    }
}

// Ensure the following namespace exists in your project:
namespace Persistencia
{
    public class ProductoPersistencia
    {
        public List<Producto> CargarTodos()
        {
            // Implementación de ejemplo
            return new List<Producto>();
        }
    }
}
