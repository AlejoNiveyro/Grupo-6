﻿using Persistencia;
using Entidades;

namespace Negocio
{
    public class LoginNegocio
    {
        public LoginResultado Autenticar(string usuario, string clave, out string mensaje)
        {
            var resultado = new LoginResultado();
            var usuarioEncontrado = UsuarioPersistencia.ObtenerUsuario(usuario);

            if (usuarioEncontrado == null)
            {
                resultado.Autenticado = false;
                resultado.Mensaje = "Usuario no encontrado.";
                resultado.Perfil = "N/A";
                mensaje = null;
                return resultado;
            }

            if (usuarioEncontrado.Clave != clave)
            {
                resultado.Autenticado = false;
                resultado.Mensaje = "Contraseña incorrecta.";
                resultado.Perfil = "N/A";
                mensaje = null;
                return resultado;
            }

            resultado.Autenticado = true;
            resultado.Mensaje = "Login exitoso.";
            resultado.Perfil = usuarioEncontrado.Perfil;
            resultado.UsuarioAutenticado = usuarioEncontrado;
            mensaje = null;
            return resultado;
        }
    }
}
