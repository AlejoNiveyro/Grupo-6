﻿using System;
using Datos.Login;
using Entidades;
using Persistencia;

namespace Negocio
{
    public class UsuarioNegocio
    {
        public Entidades.Usuario ObtenerUsuario(string usuario)
        {
            var usr = UsuarioPersistencia.ObtenerUsuario(usuario);
            if (usr != null)
            {
                usr.Perfil = UsuarioPersistencia.ObtenerPerfilPorLegajo(usr.Legajo);
            }
            return usr;
        }

        public bool EstaBloqueado(string usuario)
        {
            return UsuarioPersistencia.EstaBloqueado(usuario);
        }

        public void RegistrarIntentoFallido(string usuario)
        {
            UsuarioPersistencia.RegistrarIntentoFallido(usuario);
        }

        public void BloquearUsuario(string usuario)
        {
            UsuarioPersistencia.BloquearUsuario(usuario);
        }

        public void CambiarClave(string usuario, string nuevaClave)
        {
            UsuarioPersistencia.CambiarClave(usuario, nuevaClave);
        }

        public void ActualizarFechaLogin(string usuario)
        {
            UsuarioPersistencia.ActualizarFechaUltimoLogin(usuario, DateTime.Now);
        }
        public void DesbloquearUsuario(string usuario)
        {
            UsuarioPersistencia.DesbloquearUsuario(usuario);
        }

        public void MarcarCambioClaveObligatorio(string usuario)
        {
            UsuarioPersistencia.MarcarClaveComoRequerida(usuario);
        }
    }
}
